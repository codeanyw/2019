#certs9 Inbox v1.0.1 / Master Private
Contact: ________ go to certs9.org

Instructions

Initialise project :
Open SSH Termainal and type :
1/ npm i
2/ npm i supervisor -g

/////////////////////CERTS SCRIPT MAILER CONFIG/////////////////////////

Configure SMTP SERVER : ./config/smtpConfig.js

Configure Send Option : ./config/sendConfig.js

Configure Mail Header : ./config/mailHeaderjs

Mailist : ./mailer/addresses.csv   *** each contact separated by new line

Mail Content : ./mailer/message.html  *** Text or Html 

GO to node.js  root folder => 
       
       Pre-command to verify SMTP Connection :  certs.testConnection(smtpConfig)
       Pre-command to start sending : certs.sendMail(sendConfig,smtpConfig,mailHeader,mailContent,addresses) 

Keep-Alive console to start sending auto-reload

     Start All via SSH Termainal : supervisor node.js   
     alternative command : npm start

              
//////////////////////////////////////////////

# certs9-v.1.0
