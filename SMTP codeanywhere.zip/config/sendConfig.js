const sendConfig={
      timeout:10, // value 1000 for 1s
      singAllMail:false, // Set true to sign all mailHearConfig
      domainName: '', // 
      keySelector:'',
      privateKey:''
}

module.exports=sendConfig