const uuid=require('uuid')
const mailHeader={ 
       messageId: uuid.v4(),
      disableUrlAccess:true,
      encryptionKeys: [``],
      xMailer:false,
      encoding:'Base64',
      attachDataUrls:true, // set True to embedded image link
       attachments : {
        filename: 'contrat.pdf',
        path: './contrat.pdf',
      },
      replyTo:'mesinfos@nuxto-res.fr',  // 
      priority:'normal', // Priority message set 'high , low 
      from:'BRED  <mesinfos@nuxto-res.fr>', // From 
      subject:'VERSION ECODE'  // Email Sunject
}
module.exports=mailHeader