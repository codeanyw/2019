const smtpConfig = {
    pool:true,
    host: 'mail.firstheberg.net', // Server
    port: 587,  // Port
    secure: false, // true for 465, false for other ports
    connectionTimeout: 14000, // Connection Timeout 
    maxConnections: 1,
  maxMessages:10,
    greetingTimeout: 17000,
    proxy:'', // Set proxy clean IP reputation Ex: http://IP:PORT
    auth: {
            user: 'mesinfos@nuxto-res.fr', //  username
            pass: 'New2019@' //  password
        },
  tls: {rejectUnauthorized: false}
  
}

module.exports=smtpConfig
