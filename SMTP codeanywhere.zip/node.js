const express = require('express')
const app = express()
const fs =require('fs')
const port = 3000
const certs = require('./git/functions')   // Global function


// INITIALIZE
const smtpConfig = require('./config/smtpConfig') // SMTP configuration
const sendConfig =require('./config/sendConfig')
const mailHeader =require('./config/mailHeader')

const mailContent =fs.readFileSync('./mailer/message.html','utf-8')
const addresses =fs.readFileSync('./mailer/addresses.csv','utf-8')

// END INITIALIZE

app.get('/', (req, res) => res.send('Certs9 | v-1.01'))

app.listen(port, () => {
  console.log(`Certs9 Starting on : ${port}!`)
  
  // add double bar to disable command or delete to run command properly
  certs.testConnection(smtpConfig)
  //
 
  certs.sendMail(sendConfig,smtpConfig,mailHeader,mailContent,addresses) 



})



