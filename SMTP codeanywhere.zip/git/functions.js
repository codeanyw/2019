const nodemailer =require('nodemailer')
const Window =require('window')
const jsdom =require('jsdom')
const htmlToText = require('nodemailer-html-to-text').htmlToText;
const dom = new jsdom.JSDOM(`<!DOCTYPE html>`);
global.$ = require("jquery")(dom.window);
global.document = dom.window;
global.window = new Window()
const task = require("idle-timeout")
//const uuid=require('uuid')


module.exports={
 testConnection(smtpConfig){
   
   var config =nodemailer.createTransport(smtpConfig)
   var response = config.verify().then(res=>{
     console.log('Success SMTP worked : '+res)
     
   }).catch(err=>{
     console.log('Failed  : '+err)
   })
    
   
    
  },
  
  sendMail(sendConfig='',smtpConfig='',mailHeader='',mailContent='',addresses=''){
    var mailer=""
   var sc=[]
    var i=0;
    var config=nodemailer.createTransport(smtpConfig)
    config.use('compile', htmlToText());
    var  contacts = addresses.split("\n");
        contacts = contacts.filter(function(e) {
          return e.replace(/(\r\n|\n|\r)/gm, "");
        });
    var sizeContacts =contacts.length
    
   if(sendConfig.signAllMail===true){
     mailHeader.dkim={
       domainName :sendConfig.domainName,
       keySelector:sendConfig.keySelector,
       privateKey:sendConfig.privateKey
       
     }
   }
    mailHeader.html=mailContent
    
   mailer = task(
  () => {
    
     mailHeader.to=contacts[i]
     var mailOptions =mailHeader
  // send next message from the pending queue
    // config.close()
   if(config.isIdle){
      console.log('keep alive ')
    } else{
      console.log('Try to poole')
    }
    if(config.isIdle() && i<sizeContacts+1 ) {
      config.sendMail(mailOptions).then(res=>{
       i++
       console.log(i+' / '+sizeContacts+' sent | '+mailHeader.to+' Success => '+JSON.stringify(res.response))
       if(i==sizeContacts){
      mailer.pause()
        config.close()
        console.log('\n Send successfully')
    } else{
       mailer.reset()
    }
      
     }).catch(err=>{
         i++
         console.log(i+' '+sizeContacts+' sent | '+mailHeader.to +' Failed => '+JSON.stringify(err.response))
        if(i==sizeContacts){
           config.close()
          console.log('\n Send successfully')
      mailer.pause()
    } else{
      
       mailer.reset()
    }
     })
  }  else {
     if(i==sizeContacts){
           config.close()
          console.log('\n Send successfully')
      mailer.pause()} else{ mailer.reset()}
  }
  

  
  },
  {
   // element: document,
    timeout: sendConfig.timeout,
    loop: false
  }
);

   
   
    
  }
}